import React from 'react'

const Contact = () => {
  return (
    <div className="card">
    <div className="card-body">
      <h2>Contact US!</h2>
      <p>Maisammaguda, Dulapally, Hyderabad,
Telangana 500100<br/>

info@mallareddyuniversity.ac.in  <br/> 

+91-94971-94971 / 91778-78365</p>
    </div>
  </div>
  )
}

export default Contact