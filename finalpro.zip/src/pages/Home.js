import TaskList from '../components/TaskList';
import AddTask from '../components/AddTask';

const Home = () => (
  <>
    <AddTask />
    <TaskList />
  </>
);

export default Home;